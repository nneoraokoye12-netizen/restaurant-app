package edu.bpi.restarauntapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Contact extends AppCompatActivity {

    Button homeButton;
    Button cateringButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        // Initialize buttons
        homeButton = findViewById(R.id.home2);
        cateringButton = findViewById(R.id.catering2);

        // HOME button go back to MainActivity
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeIntent = new Intent(Contact.this, MainActivity.class);
                startActivity(homeIntent);
                finish();
            }
        });

        // CATERING button go to Catering.java
        cateringButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cateringIntent = new Intent(Contact.this, Catering.class);
                startActivity(cateringIntent);
            }
        });
    }
}