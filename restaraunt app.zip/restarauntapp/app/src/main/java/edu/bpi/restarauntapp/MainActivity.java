package edu.bpi.restarauntapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button cateringButton;
    Button contactButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize buttons
        cateringButton = findViewById(R.id.catering);
        contactButton = findViewById(R.id.contact);

        // When Catering button is clicked go to Catering.java
        cateringButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cateringIntent = new Intent(MainActivity.this, Catering.class);
                startActivity(cateringIntent);
            }
        });

        // When Contact Us button is clicked go to Contact.java
        contactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent contactIntent = new Intent(MainActivity.this, Contact.class);
                startActivity(contactIntent);
            }
        });
    }
}