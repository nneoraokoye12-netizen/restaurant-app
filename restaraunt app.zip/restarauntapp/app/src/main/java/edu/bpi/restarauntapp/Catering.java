package edu.bpi.restarauntapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Catering extends AppCompatActivity {

    Button homeButton;
    Button contactButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catering);

        // Initialize buttons
        homeButton = findViewById(R.id.home);
        contactButton = findViewById(R.id.contact);

        // When HOME button is clicked go back to MainActivity
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeIntent = new Intent(Catering.this, MainActivity.class);
                startActivity(homeIntent);
                finish();
            }
        });

        // When CONTACT US button is clicked go to Contact.java
        contactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent contactIntent = new Intent(Catering.this, Contact.class);
                startActivity(contactIntent);
            }
        });
    }
}